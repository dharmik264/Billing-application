import 'dart:typed_data';
import 'dart:io';

import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:shared_preferences/shared_preferences.dart';

import 'restaurant_api.dart';

class PrinterService {
  PrinterService._privateConstructor();
  static final PrinterService instance = PrinterService._privateConstructor();

  final BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;
  String? _printerIp;
  bool _isNetworkPrinter = false;
  PaperSize _paperSize = PaperSize.mm58;

  bool _lastConnectionStatus = false;
  DateTime _lastConnectionCheck = DateTime.fromMillisecondsSinceEpoch(0);

  Future<void> initPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    final sizeStr = prefs.getString('paper_size') ?? '58 mm';
    _paperSize = sizeStr == '80 mm' ? PaperSize.mm80 : PaperSize.mm58;

    _printerIp = prefs.getString('printer_ip');
    _isNetworkPrinter = prefs.getBool('is_network_printer') ?? false;
  }

  Future<List<BluetoothDevice>> getDevices() async {
    try {
      return await bluetooth.getBondedDevices();
    } catch (e) {
      return [];
    }
  }

  Future<bool> connect(BluetoothDevice device) async {
    try {
      await bluetooth.connect(device);
      _isNetworkPrinter = false;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('printer_mac', device.address ?? '');
      await prefs.setBool('is_network_printer', false);
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<void> disconnect() async {
    try {
      await bluetooth.disconnect();
      _isNetworkPrinter = false;
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('printer_mac');
      await prefs.remove('printer_ip');
      await prefs.remove('is_network_printer');
      // ignore: empty_catches
    } catch (e) {}
  }

  Future<bool> connectNetwork(String ip) async {
    try {
      final socket =
          await Socket.connect(ip, 9100, timeout: const Duration(seconds: 3));
      socket.destroy();

      _printerIp = ip;
      _isNetworkPrinter = true;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('printer_ip', ip);
      await prefs.setBool('is_network_printer', true);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> get isConnected async {
    if (kIsWeb) return false;

    final now = DateTime.now();
    if (now.difference(_lastConnectionCheck).inSeconds < 5) {
      return _lastConnectionStatus;
    }

    if (_isNetworkPrinter && _printerIp != null && _printerIp!.isNotEmpty) {
      try {
        final socket = await Socket.connect(_printerIp!, 9100,
            timeout: const Duration(seconds: 1));
        socket.destroy();
        _lastConnectionStatus = true;
      } catch (_) {
        _lastConnectionStatus = false;
      }
    } else {
      _lastConnectionStatus = await bluetooth.isConnected ?? false;
    }

    _lastConnectionCheck = now;
    return _lastConnectionStatus;
  }

  Future<void> writeBytes(List<int> bytes) async {
    if (_isNetworkPrinter && _printerIp != null && _printerIp!.isNotEmpty) {
      try {
        final socket = await Socket.connect(_printerIp!, 9100,
            timeout: const Duration(seconds: 3));
        socket.add(bytes);
        await socket.flush();
        await socket.close();
      } catch (e) {
        // print failed
      }
    } else {
      bluetooth.writeBytes(Uint8List.fromList(bytes));
    }
  }

  Future<void> attemptAutoConnect() async {
    if (kIsWeb) return;
    
    await initPreferences();
    if (_isNetworkPrinter) return;

    final prefs = await SharedPreferences.getInstance();
    final mac = prefs.getString('printer_mac');
    if (mac != null && mac.isNotEmpty) {
      final devices = await getDevices();
      final device = devices.where((d) => d.address == mac).firstOrNull;
      if (device != null) {
        await connect(device);
      }
    }
  }

  Future<void> printReceipt(
      ApiToken token, ApiShopData shopData, ApiBillTemplate template) async {
    final connected = await isConnected;
    if (!connected) return;

    final profile = await CapabilityProfile.load();
    final generator = Generator(_paperSize, profile);
    List<int> bytes = [];

    // Header
    bytes += generator.text(shopData.name,
        styles: const PosStyles(
            align: PosAlign.center,
            height: PosTextSize.size2,
            width: PosTextSize.size2,
            bold: true));
    if (shopData.address != null && shopData.address!.isNotEmpty) {
      bytes += generator.text(shopData.address!,
          styles: const PosStyles(align: PosAlign.center));
    }
    if (shopData.phone != null && shopData.phone!.isNotEmpty) {
      bytes += generator.text('Tel: ${shopData.phone}',
          styles: const PosStyles(align: PosAlign.center));
    }
    if (shopData.gstin != null && shopData.gstin!.isNotEmpty) {
      bytes += generator.text('GST: ${shopData.gstin}',
          styles: const PosStyles(align: PosAlign.center));
    }
    bytes += generator.feed(1);

    // Bill Details
    bytes += generator.text('Token: ${token.tokenNumber}',
        styles: const PosStyles(bold: true));
    bytes += generator.text('Bill No: ${token.billNumber}');
    bytes += generator.text('Date: ${token.createdAt.split('T').first}');
    if (token.customerName.isNotEmpty) {
      bytes += generator.text('Customer: ${token.customerName}');
    }
    bytes += generator.feed(1);

    // Items Header
    bytes += generator.row([
      PosColumn(text: 'Item', width: 6, styles: const PosStyles(bold: true)),
      PosColumn(text: 'Qty', width: 2, styles: const PosStyles(bold: true)),
      PosColumn(
          text: 'Amount',
          width: 4,
          styles: const PosStyles(align: PosAlign.right, bold: true)),
    ]);
    bytes += generator.hr();

    // Items
    for (final item in token.items) {
      bytes += generator.row([
        PosColumn(text: item.name, width: 6),
        PosColumn(text: '${item.quantity}', width: 2),
        PosColumn(
            text: item.subtotal.toStringAsFixed(2),
            width: 4,
            styles: const PosStyles(align: PosAlign.right)),
      ]);
    }
    bytes += generator.hr();

    // Totals
    final subtotal = token.items.fold(0.0, (sum, i) => sum + i.subtotal);
    bytes += generator.row([
      PosColumn(text: 'Subtotal', width: 8),
      PosColumn(
          text: subtotal.toStringAsFixed(2),
          width: 4,
          styles: const PosStyles(align: PosAlign.right)),
    ]);

    bytes += generator.feed(1);
    bytes += generator.row([
      PosColumn(
          text: 'Grand Total', width: 8, styles: const PosStyles(bold: true)),
      PosColumn(
          text: token.grandTotal.toStringAsFixed(2),
          width: 4,
          styles: const PosStyles(align: PosAlign.right, bold: true)),
    ]);

    bytes += generator.feed(1);
    bytes += generator.text('Payment Mode: ${token.paymentMode}',
        styles: const PosStyles(align: PosAlign.center));

    if (template.footerMessage.isNotEmpty) {
      bytes += generator.feed(1);
      bytes += generator.text(template.footerMessage,
          styles: const PosStyles(align: PosAlign.center));
    }

    bytes += generator.feed(2);
    bytes += generator.cut();

    await writeBytes(bytes);
  }

  Future<void> printKitchenSlip(ApiToken token) async {
    final connected = await isConnected;
    if (!connected) return;

    final profile = await CapabilityProfile.load();
    final generator = Generator(_paperSize, profile);
    List<int> bytes = [];

    bytes += generator.text('KITCHEN SLIP',
        styles: const PosStyles(
            align: PosAlign.center,
            height: PosTextSize.size2,
            width: PosTextSize.size2,
            bold: true));
    bytes += generator.feed(1);

    bytes += generator.text('Token: ${token.tokenNumber}',
        styles: const PosStyles(bold: true, height: PosTextSize.size2));
    bytes += generator.text('Order Type: ${token.orderType.toUpperCase()}',
        styles: const PosStyles(bold: true));
    bytes += generator.text('Date: ${token.createdAt.split('T').first}');
    bytes += generator.feed(1);

    bytes += generator.row([
      PosColumn(text: 'Item', width: 9, styles: const PosStyles(bold: true)),
      PosColumn(
          text: 'Qty',
          width: 3,
          styles: const PosStyles(align: PosAlign.right, bold: true)),
    ]);
    bytes += generator.hr();

    for (final item in token.items) {
      bytes += generator.row([
        PosColumn(
            text: item.name, width: 9, styles: const PosStyles(bold: true)),
        PosColumn(
            text: '${item.quantity}',
            width: 3,
            styles: const PosStyles(
                align: PosAlign.right, bold: true, height: PosTextSize.size2)),
      ]);
      bytes += generator.feed(1);
    }

    bytes += generator.feed(2);
    bytes += generator.cut();

    await writeBytes(bytes);
  }

  Future<void> printTest() async {
    final connected = await isConnected;
    if (!connected) return;

    final profile = await CapabilityProfile.load();
    final generator = Generator(_paperSize, profile);
    List<int> bytes = [];

    bytes += generator.text('Test Print Successful!',
        styles: const PosStyles(
            align: PosAlign.center,
            bold: true,
            height: PosTextSize.size2,
            width: PosTextSize.size2));
    bytes += generator.feed(2);
    bytes += generator.cut();

    await writeBytes(bytes);
  }
}
